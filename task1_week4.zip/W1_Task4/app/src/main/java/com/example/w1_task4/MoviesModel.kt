package com.example.w1_task4

class MoviesModel (
    val results: List<Result>
)
data class Result(
    val popularity: Double,
    val vote_count: Int,
    val video: Boolean,
    val poster_path: String,
    val id: Int,
    val adult: Boolean,
    val backdrop_path: String,
    val original_language: String,
    val original_title: String,
    val genre_ids: IntArray,
    val title: String,
    val vote_average: Double,
    val overview: String,
    val release_date: String
)